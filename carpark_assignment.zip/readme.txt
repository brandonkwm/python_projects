#description
- user can input a date + backward shifter and script will run api calls on each date to gather data (for trend analysis)
- duplicated data is removed
- data with ELECTRONIC PARKING and WHOLE DAY parking are kept
- introduced a lot % utilization for users to see. Users can decide lot % utilization threshold in config file
- introduced a quantile column for users to choose if they want to see only the top few percentiles of large carparks. Users can put a 0 in config file to load all car parks.
- carParkData.py does the creation of dataframes (coming from JSON and csv input)
- dataParse.py does the work on the data once it has been aggregated by carParkData.py
- run on python3

#instructions
1. Place all input files (config file, csv) in python working directory
2. Configure config.cfg. Instructions in config.cfg. 
3. Execute parseData.py
4. .xlsx report output 2 files containing (sample attached):
	- size_data_report.xlsx
	- util_data_report.xlsx