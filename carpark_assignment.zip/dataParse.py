import carParkData
import os

def util_data(thold):
    #take config file value threshold for lot utilization
    carParkData.dfgrouped = carParkData.dfmergecol.groupby('car_park_no')
    carParkData.dfmergecol['total_lots'] = carParkData.dfmergecol['total_lots'].astype(float)
    carParkData.dfmergecol['lots_available'] = carParkData.dfmergecol['lots_available'].astype(float)
    carParkData.dfmergecol['lot % utilization'] = round((carParkData.dfmergecol['total_lots']-carParkData.dfmergecol['lots_available']) / carParkData.dfmergecol['total_lots']*100,3)
    filtmerge = carParkData.dfmergecol['lot % utilization'] <= float(thold)
    dfutil_merge = carParkData.dfmergecol.loc[filtmerge].sort_values(by=['update_date','lot % utilization'], ascending=False)
    dfutil_merge.to_excel(os.getcwd()+'/'+carParkData.util_report_name,index=False,header=True)

def large_carpark_data(quant):
     dfsize = carParkData.dfmergecol.sort_values(by=['update_date','total_lots'],ascending=False)
     dfsize['total_lots percentile'] = round((dfsize['total_lots'] / dfsize['total_lots'].quantile(1.0))*100,3)
     filt = dfsize['total_lots percentile'] >= float(quant)
     dfsize_quantile = dfsize.loc[filt]
     dfsize_quantile = dfsize_quantile.drop_duplicates()
     dfsize_quantile.to_excel(os.getcwd()+'/'+carParkData.size_report_name,index=False, header=True)

util_data(carParkData.lot_threshold)
large_carpark_data(carParkData.totallots_quantile)